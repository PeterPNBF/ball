package ball;

import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public class GetNextSerials {

    public static void getNextSerials() throws IOException {
        Set<Integer> predictSet = new HashSet<>();
        int shot = 0;
        int shotTotal = 0;
        List<Set<Integer>> red = new ArrayList<Set<Integer>>();
        List<Integer> blue = new ArrayList<>();
        List<Ball> redBalls = new ArrayList<>();
        List<Ball> blueBalls = new ArrayList<>();
        for(int i=0;i<34; ++i){
            Ball ball = new Ball();
            ball.no=i;
            redBalls.add(ball);
        }
        for(int i=0;i<17; ++i){
            Ball ball = new Ball();
            ball.no=i;
            blueBalls.add(ball);
        }
        BufferedReader bufferedReader = new BufferedReader(new FileReader("G:\\caipiao\\data.txt"));
        String str = null;
        int count = 0;
        while((str=bufferedReader.readLine())!=null && str.length()>0){
            count++;
            shot = 0;
            String[] sstr = str.split("[    \t]+");
            Set<Integer> rs = new HashSet<>();
            red.add(rs);
            for(int i=1; i<7; ++i){
                int tmp = Integer.parseInt(sstr[i]);
                if(predictSet.contains(tmp)){
                    shot++;
                }
                rs.add(tmp);
                redBalls.get(tmp).count++;
                redBalls.get(tmp).count10++;
                redBalls.get(tmp).count20++;
                redBalls.get(tmp).count30++;
                redBalls.get(tmp).count50++;
                redBalls.get(tmp).count100++;
            }

            if(count>10){
                for(Ball ball : redBalls) {
                    if (red.get(count - 11).contains(ball.no)) {
                        ball.count10--;
                    }
                }
            }
            if(count>20){
                for(Ball ball : redBalls) {
                    if (red.get(count - 21).contains(ball.no)) {
                        ball.count20--;
                    }
                }
            }
            if(count>30){
                for(Ball ball : redBalls) {
                    if (red.get(count - 31).contains(ball.no)) {
                        ball.count30--;
                    }
                }
            }
            if(count>50){

                for(Ball ball : redBalls) {
                    if (red.get(count - 51).contains(ball.no)) {
                        ball.count50--;
                    }
                }
            }
            if(count>100){
                for(Ball ball : redBalls) {
                    if (red.get(count - 101).contains(ball.no)) {
                        ball.count100--;
                    }
                }
            }
//            System.out.println("predictSet=" + predictSet);
//            System.out.println("rs=" + rs);
//            System.out.println("count=" + count);
            if(shot>=3){
                shotTotal++;
                System.out.println("count=" + count + ",shot=" + shot);
                System.out.println("predictSet=" + predictSet);
                printBalls10(redBalls);
                printBalls100(redBalls);
                System.out.println(str);
            }
            Integer tmp = Integer.parseInt(sstr[7]);
            blue.add(tmp);
            blueBalls.get(tmp).count++;
            blueBalls.get(tmp).count10++;
            blueBalls.get(tmp).count20++;
            blueBalls.get(tmp).count30++;
            blueBalls.get(tmp).count50++;
            blueBalls.get(tmp).count100++;
            if(count>10){
                if(blue.get(count-11).equals(tmp)){
                    blueBalls.get(tmp).count10--;
                }
            }
            if(count>20){
                if(blue.get(count-21).equals(tmp)){
                    blueBalls.get(tmp).count20--;
                }
            }
            if(count>30){
                if(blue.get(count-31).equals(tmp)){
                    blueBalls.get(tmp).count30--;
                }
            }
            if(count>50){
                if(blue.get(count-51).equals(tmp)){
                    blueBalls.get(tmp).count50--;
                }
            }
            if(count>100){
                if(blue.get(count-101).equals(tmp)){
                    blueBalls.get(tmp).count100--;
                }
            }

            for(int i=1;i<34; ++i){
                redBalls.get(i).percent = (redBalls.get(i).count*1000/count)/10.0f;
                redBalls.get(i).percent10 = (redBalls.get(i).count10*1000/10)/10.0f;
                redBalls.get(i).percent20 = (redBalls.get(i).count20*1000/20)/10.0f;
                redBalls.get(i).percent30 = (redBalls.get(i).count30*1000/30)/10.0f;
                redBalls.get(i).percent50 = (redBalls.get(i).count50*1000/50)/10.0f;
                redBalls.get(i).percent100 = (redBalls.get(i).count100*1000/100)/10.0f;
            }
            for(int i=1;i<17; ++i){
                blueBalls.get(i).percent = (blueBalls.get(i).count*1000/count)/10.0f;
                blueBalls.get(i).percent10 = (blueBalls.get(i).count10*1000/10)/10.0f;
                blueBalls.get(i).percent20 = (blueBalls.get(i).count20*1000/20)/10.0f;
                blueBalls.get(i).percent30 = (blueBalls.get(i).count30*1000/30)/10.0f;
                blueBalls.get(i).percent50 = (blueBalls.get(i).count50*1000/50)/10.0f;
                blueBalls.get(i).percent100 = (blueBalls.get(i).count100*1000/100)/10.0f;
            }

            List<Ball> redBallsCopy = new ArrayList<>();
            List<Ball> blueBallsCopy = new ArrayList<>();
            for(int i=0;i<34; ++i){
                Ball ball = new Ball();
                ball.no=i;
                redBallsCopy.add(redBalls.get(i));
            }
            for(int i=0;i<17; ++i){
                Ball ball = new Ball();
                ball.no=i;
                blueBallsCopy.add(blueBalls.get(i));
            }
            Collections.sort(redBallsCopy, new Comparator<Ball>() {
                @Override
                public int compare(Ball o1, Ball o2) {
                    return o2.count100-o1.count100;
                }
            });

            predictSet.clear();
            int pickNum = 8;
            int additionCnt = 2;

            List<Ball> predictList = new ArrayList<>();
            for(int i=0; i<pickNum; ++i){
                int no = redBallsCopy.get(i).no;
                predictSet.add(no);
                predictList.add(0,redBallsCopy.get(i));
            }

//            if(count>20) {
//
//                printBalls(redBallsCopy);
//            }
            Collections.sort(redBallsCopy, new Comparator<Ball>() {
                @Override
                public int compare(Ball o1, Ball o2) {
                    return o2.count10-o1.count10;
                }
            });
            if(count==138){
                System.out.print("");
            }
            int removeCnt = 0;
            int percentTh = 31;
            for(Ball ball : redBallsCopy){
                if(ball.percent10<percentTh || removeCnt>=additionCnt){
                    break;
                }
                if(ball.percent10>=percentTh && predictSet.contains(ball.no)){
                    removeCnt++;
                    predictSet.remove(ball.no);
                }
            }
            Iterator<Ball> it = predictList.iterator();
            while(it.hasNext()){
                Ball ball = it.next();
                if(ball.percent10<=11){
                    continue;
                }
                predictSet.remove(ball.no);
                it.remove();
                if(++removeCnt>=additionCnt){
                    break;
                }
            }
//            if(count>20) {
//                printBalls10(redBallsCopy);
//                for(Set<Integer> sets : red){
//                    System.out.println(sets);
//                }
//                System.in.read();
//            }

        }

        System.out.println("count=" + count + ",shotTotal=" + shotTotal);
    }

    private static void printBalls(List<Ball> redBallsCopy) {
        System.out.println();
        System.out.println("------------");
        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            System.out.printf("%-6d" ,ball.no);
        }

        System.out.println();

        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            System.out.printf("%-6d" ,ball.count);
        }

        System.out.println();
        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            DecimalFormat df = new DecimalFormat("00.0  ");
            System.out.printf("%s" ,df.format(ball.percent));
        }
        System.out.println();
        System.out.println("------------");
    }

    private static void printBalls100(List<Ball> redBallsCopy) {
        System.out.println();
        System.out.println("100------------100");
        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            System.out.printf("%-6d" ,ball.no);
        }

        System.out.println();

        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            System.out.printf("%-6d" ,ball.count100);
        }

        System.out.println();
        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            DecimalFormat df = new DecimalFormat("00.0  ");
            System.out.printf("%s" ,df.format(ball.percent100));
        }
        System.out.println();
        System.out.println("100------------100");
    }


    private static void printBalls10(List<Ball> redBallsCopy) {
        System.out.println();
        System.out.println("10------------10");
        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            System.out.printf("%-6d" ,ball.no);
        }

        System.out.println();

        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            System.out.printf("%-6d" ,ball.count10);
        }

        System.out.println();
        for(Ball ball : redBallsCopy){
            if(ball.no==0)continue;
            DecimalFormat df = new DecimalFormat("00.0  ");
            System.out.printf("%s" ,df.format(ball.percent10));
        }
        System.out.println();
        System.out.println("10------------10");
    }



    public static void main(String[] args) throws IOException {
        GetNextSerials.getNextSerials();
    }
}
